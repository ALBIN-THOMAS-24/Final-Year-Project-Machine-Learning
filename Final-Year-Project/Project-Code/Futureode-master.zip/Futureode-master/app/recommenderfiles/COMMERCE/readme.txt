TOTRM - BCom Tourism & Travel Management
MARK  - BCom Marketing
BUAD  - BCOM_BUSINESS & ADMINISTRATION
BAFI  - BCOM BANKING AND FINANCE
APPE  - BCOM APPLIED ECONOMICS
ACC   - BCOM IN ACCOUNTING
MAIF  - BCom in Management Accounting & International Finance
STCS  - BCOM STATISTICS
ACTA  - Bcom Accounting and taxation
